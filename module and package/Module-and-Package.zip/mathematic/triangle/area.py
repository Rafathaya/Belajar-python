def area_of_triangle(base, height):
  result = (base * height) / 2
  text = f"the area of the triangle is {result}"
  print(text)