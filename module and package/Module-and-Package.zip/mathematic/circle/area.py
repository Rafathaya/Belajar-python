def circle_area(radius):
    pi = 22/7
    result = pi * radius * radius
    text = f"The area of the circle is {result}"
    print(text)