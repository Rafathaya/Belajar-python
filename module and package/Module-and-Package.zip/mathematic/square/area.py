def area_of_square(side):
  result = side * side
  text = f"the area of the square is {result}"
  print(text)