def area_of_square(side):
  result = side * side
  text = f"the area of the square is {result}"
  print(text)

def area_of_triangle(base, height):
  result = (base * height) / 2
  text = f"the area of the triangle is {result}"
  print(text)
