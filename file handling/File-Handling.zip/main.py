#membuat file baru
#open('file_pertama.txt', 'x')

#untuk membaca file
#file = open('file_pertama.txt', 'r')
#print(file.read())

#membuat konten pada file
#file = open('file_pertama.txt', 'w')
#file.write("selamat datang")
#file.write("\n")
#file.write("Nama saya adalah Rafa")
#file.close()

#nemanbahkan konten
file = open('file pertama.txt', 'a')
file.write("ini baris baru")
file.close()

